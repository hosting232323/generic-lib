import sys


hostname = (
  'https://generic-be.replit.app/'
  if len(sys.argv) > 1 and sys.argv[1] == '--production' else
  'http://127.0.0.1:8080/'
  if len(sys.argv) > 1 and sys.argv[1] == '--local' else
  'https://generic-be-test.replit.app/'
)
