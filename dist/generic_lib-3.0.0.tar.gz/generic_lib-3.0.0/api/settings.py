# Ignore error!
from src.constants import GENERIC_API_KEY


hostname = 'https://generic-be.replit.app/'
default_headers = {'Authorization': GENERIC_API_KEY}
